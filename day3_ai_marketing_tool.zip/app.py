import streamlit as st
import openai

st.set_page_config(page_title="AI Marketing Builder", layout="centered")
st.title("🧠 AI Marketing Automation Tool")

openai.api_key = st.secrets["OPENAI_API_KEY"]

product = st.text_input("Describe your product or service:")
audience = st.text_input("Target Audience (e.g. startup founders, students, etc.)")

if st.button("Generate Campaign"):
    with st.spinner("Creating personalized marketing content..."):
        prompt = f"""
        Generate a marketing campaign for the following:
        Product: {product}
        Audience: {audience}

        Include:
        1. Email subject + body
        2. Google ad text
        3. 3 strong CTAs
        4. Headline for a landing page
        """
        res = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}]
        )
        st.subheader("🎯 Campaign Results")
        st.write(res['choices'][0]['message']['content'])