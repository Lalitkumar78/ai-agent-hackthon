# 🧠 AI-Powered Marketing Automation (Day 3)

This is my final project submission for **Day 3** of the **AI Agent Hackathon** by Product Space.

## 💼 What it does
Enter a product and target audience → Get complete marketing content: emails, ads, landing pages.

## 🛠 Built with
- Streamlit
- OpenAI API

## 🚀 How to Run

```bash
pip install -r requirements.txt
streamlit run app.py
```

## 🔐 API Setup
Create `.streamlit/secrets.toml` and add:
```toml
OPENAI_API_KEY = "your-key"
```